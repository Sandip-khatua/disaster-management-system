# Natural-Disaster-Management-System
Software Engineering Project using HTML5, CSS3, PHP and JavaScript

The best way to handle a disaster is to be prepared in advance. 
Besides, with careful planning, the effects of a disaster can be minimized manifold. 
The software does not store details of past disasters but relies on the government updated data.
It is an extension to the already existing government website on disaster management in India and is focused on natural disasters in India and an interactive way to guide the citizens about 
the do’s and don’ts during and after a natural disaster.

