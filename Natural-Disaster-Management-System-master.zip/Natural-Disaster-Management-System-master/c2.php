<html>
<body>
<head>
<title> Activity 2c</title>
</head>


<form action="check.php" method="post">
Stud_Id: <input type="text" name="id" />
Stud_Name: <input type="text" name="name" />
Age: <input type="text" name="age" >
<input type="submit" value = "submit qry">
<input type="reset" value ="reset">
</form>
</body>
</html>
