        	  <div class="cleaner"></div>
            <div class="box">
            	<h3><span></span>News</h3>

                <img src="images/quake.jpg" alt="image" />
                <div class="news_title"><a href="http://edition.cnn.com/2015/04/29/asia/nepal-earthquake/"> Nepal Earthquake</a></div>
                <p>Nepal- A powerful earthquake, the country's worst in 80 years, rocked mountainous Nepal on Saturday, 25th April. On Sunday, Nepal was struck by a major aftershock.</p>
		<div class="cleaner"></div>
		<br/>
		<img src="images/quake2.jpg"/>
		<div class="news_title"><a href="http://www.bloomberg.com/news/articles/2015-04-27/counting-the-economic-cost-of-natural-disasters">Counting the Economic Cost of Natural Disasters</a></div>
		<p>The Asia-Pacific region is the world's most disaster-prone, with earthquakes and floods wreaking havoc on economies.</p>

          </div>

      </div> <!-- end of side column -->
	  
