 <div id="templatemo_footer">
        Designed by Krati, Divyansh, Bhupesh and Sai Yogesh

        <div class="cleaner_h20"></div>

        
    </div> <!-- end of footer -->
</div> <!-- end of templatemo  container -->

<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js'></script>
<script type='text/javascript' src='js/logging.js'></script>
<?php mysqli_close($connection); ?>
</body>
</html>