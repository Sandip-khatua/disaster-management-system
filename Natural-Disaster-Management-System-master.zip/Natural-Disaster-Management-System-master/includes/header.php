<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php    $connection=mysqli_connect("localhost","root","","ndms");
    if(!$connection)
    die("connection error : ".mysql_error());
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>NDMS</title>
<meta name="keywords" content="People Template, Free CSS Layout, 2-column, " />
<meta name="description" content="free website template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="templatemo_container">

    <div id="templatemo_top_bar">
    	<div id="rss_button"></div>

        <div class="cleaner"></div>
    </div> <!-- end of top bar -->

    <div id="templatemo_content">
	

        <div id="templatemo_side_column">

        	<div id="templatemo_site_title_box">
            	<h1><a href="#">NDMS<span>Natural Disaster Management System</span></a></h1>
       	  	</div>

           

