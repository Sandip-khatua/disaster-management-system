<?php
    session_start();
    $val=$_SESSION['uname'];
?>