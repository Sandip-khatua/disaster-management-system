<?php require_once("includes/ses.php"); ?>
<?php require_once("includes/header.php"); ?>
<?php require_once("includes/nav.php"); ?>
<?php require("includes/news.php"); ?>
<!-- end of side column -->

        <div id="templatemo_main_column">

	<a href="home.php"><div id="disp_name">
	    <?php echo $val;?>
	</div></a>

 <!-- end of menu -->


      </div> <!-- end of side column -->

        <div id="templatemo_main_column">

            <div class="main_column_box">
            
            <div class="cleaner_h80"></div>
            
                <h3 id="topic1"><span></span>Contact Information</h3>

              <img id="image1" class="image_wrapper fl_image" src="images/admin3.jpg" alt="image" />
              

                <div class="cleaner"></div>
            </div>
	       <p id="cont">For any queries please contact any of the following<ul style='font-size:17px;'><li>Pinak Saini<br>+91 8056954937<br>pinak@vit.ac.in</li><br><li>Divyansh Sharma<br>+91 8870878114<br>divyansh.sharma2012@vit.ac.in</li></ul></p>

        </div>

        <div class="cleaner"></div>
        <div id="top"></div>
        <div id="bottom"></div>
    </div>

<?php require("includes/footer.php"); ?>