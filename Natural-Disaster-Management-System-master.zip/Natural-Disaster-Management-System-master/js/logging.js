$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+1013493+'&oi='+225+'&ot=1&&url='+window.location, function(json){})    

});