<html>
<body>
<form method="POST" action="validate.php">
Name:<input type="text" name="name"><br/>
email:<input type="text" name="email"><br/>
<input type="submit" name="submit"/>
</form>
</body>
</html>

